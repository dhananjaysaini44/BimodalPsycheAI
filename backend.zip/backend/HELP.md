# Bimodal Psyche - Backend System Documentation

Welcome to the backend service documentation for **Bimodal Psyche**. This repository contains a Spring Boot-based RESTful backend system designed for user authentication, identity verification, session management with JWT tokens, and user demographic profiling.

---

## Architecture Overview

The backend follows a standard multi-tiered Spring Boot architecture:

```
[ Client / Frontend ]
          │
          ▼
┌────────────────────────────────────────────────────────┐
│                   Spring Security                      │
│        (JWTFilter & Security Configuration)            │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│                  REST Controllers                      │
│                   (AuthController)                     │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│                   Service Layer                        │
│        (AuthService, OtpService, UserService)          │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│                   Data Layer                           │
│  (Repositories & Spring Data JPA Domain Entities)      │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│                 MySQL Database                         │
│       (Users, OtpVerifications, RefreshTokens)         │
└────────────────────────────────────────────────────────┘
```

### Key Modules & Components
* **Security & Auth Layer**: Implements Spring Security with custom JWT filtering (`JWTFilter`), secure SHA-256 token hashing (`TokenHashUtil`), and stateless JWT token issue/validation routines (`JWTService`).
* **Domain Layer**: Core JPA entities (`User`, `OtpVerification`, `RefreshToken`) alongside enums defining user profile demography (`Gender`, `MaritalStatus`, `EmploymentType`, `Role`).
* **Service Layer**: Core business logic modules including `AuthService` (user onboarding & login flow), `OtpService` (OTP code generation & verification lifecycle), and `UserService` (profile operations).
* **Controller Layer**: REST controllers exposing public and protected endpoints (`AuthController`).
* **Exception Handling**: Standardized central error response handling using `@ControllerAdvice` (`GlobalExceptionHandler`).

---

## Architectural Diagrams

### 1. High-Level System Component Architecture
```mermaid
graph TD
    Client[Client App / Frontend] -->|HTTPS Requests| Controller[AuthController]
    
    subgraph Spring Boot Backend Application
        Controller --> AuthService[AuthService]
        Controller --> UserService[UserService]
        AuthService --> OtpService[OtpService]
        AuthService --> JWTService[JWTService]
        AuthService --> TokenHashUtil[TokenHashUtil]
        
        JWTFilter[JWTFilter Filter Chain] -->|Intercepts & Validates Token| JWTService
        
        AuthService --> UserRepo[UserRepository]
        AuthService --> OtpRepo[OtpVerificationRepository]
        AuthService --> TokenRepo[RefreshTokenRepository]
        UserService --> UserRepo
    end

    subgraph Database Persistence
        UserRepo -->|JPA / MySQL| UserDB[(User Entity)]
        OtpRepo -->|JPA / MySQL| OtpDB[(OtpVerification Entity)]
        TokenRepo -->|JPA / MySQL| RefreshTokenDB[(RefreshToken Entity)]
    end
```

---

### 2. Authentication & Verification Sequence Flow
```mermaid
sequenceDiagram
    autonumber
    actor User as User / Client
    participant API as AuthController
    participant OTP as OtpService
    participant Auth as AuthService
    participant DB as Database Repository

    %% OTP Generation
    User->>API: POST /api/auth/send-otp (email)
    API->>OTP: sendOtp(email)
    OTP->>DB: Save Generated OTP Record
    OTP-->>User: Send OTP Code (Email Service)

    %% OTP Verification
    User->>API: POST /api/auth/verify-otp (email, otp)
    API->>OTP: verifyOtp(email, otp)
    OTP->>DB: Validate OTP & Mark Email Verified
    OTP-->>API: OTP Verification Success

    %% Registration
    User->>API: POST /api/auth/register (UserDetails)
    API->>Auth: registerUser(RegisterRequest)
    Auth->>DB: Verify email is OTP verified & save User
    Auth-->>User: User Registration Successful

    %% Login
    User->>API: POST /api/auth/login (email, password)
    API->>Auth: login(LoginRequest)
    Auth->>DB: Authenticate credentials
    Auth->>Auth: Generate Access JWT & Refresh Token
    Auth->>DB: Save Hashed Refresh Token
    Auth-->>User: Return Access Token & Set Refresh Token Cookie
```

---

### 3. User Entity-Relationship Diagram (ERD)
```mermaid
erDiagram
    USER {
        Long id PK
        String email
        String password
        String firstName
        String lastName
        Gender gender
        MaritalStatus maritalStatus
        EmploymentType employmentType
        Role role
        boolean isEmailVerified
        LocalDateTime createdAt
    }

    OTP_VERIFICATION {
        Long id PK
        String email
        String otpCode
        boolean verified
        LocalDateTime expiryTime
    }

    REFRESH_TOKEN {
        Long id PK
        String tokenHash
        String userEmail
        LocalDateTime expiryDate
    }

    USER ||--o{ REFRESH_TOKEN : "owns"
    USER ||--o{ OTP_VERIFICATION : "verifies with"
```

---

## API Endpoints Summary

All endpoints are configured under the `/api/auth` base path.

| Method | Endpoint Path | Request Payload / Input | Description | Access Level |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/send-otp` | `SendOtpRequest` (`email`) | Generates a 6-digit OTP code and dispatches it for email verification. | Public |
| `POST` | `/api/auth/verify-otp` | `OtpVerificationRequest` (`email`, `otpCode`) | Validates the OTP code to flag the email address as verified in the DB. | Public |
| `POST` | `/api/auth/register` | `RegisterRequest` (email, password, personal & demographic fields) | Registers a new account. Registration requires prior OTP email verification. | Public |
| `POST` | `/api/auth/login` | `LoginRequest` (`email`, `password`) | Authenticates user credentials and returns a short-lived JWT along with a hashed refresh token. | Public |
| `POST` | `/api/auth/refresh` | Refresh Token Cookie / Request Header | Issues a new JWT access token using a valid, unexpired refresh token. | Public (Refresh Token) |
| `POST` | `/api/auth/logout` | Authorization Header (`Bearer <JWT>`) | Invalidates the user's refresh token in the database and clears the security session. | Authenticated |

---

## Project Setup & Running

### Prerequisites
* **Java**: JDK 17 or higher
* **Database**: MySQL 8.0+
* **Build Tool**: Apache Maven (Wrapper included in project)

### Application Configuration
Configure your database connection and secrets in `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/bimodal_psyche_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=your_password
spring.jpa.hibernate.ddl-auto=update

# JWT Settings
jwt.secret=your_jwt_secret_key_here
jwt.expiration=86400000
```

### Building and Launching
```bash
# Build the project
./mvnw clean package

# Run the application
./mvnw spring-boot:run
```